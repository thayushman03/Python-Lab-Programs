# Q27. Write a program using numpy to perform array operations
# (creation, indexing, arithmetic).

import numpy as np

# ── Array Creation ────────────────────────────────
print("=== Array Creation ===")

a = np.array([1, 2, 3, 4, 5])
print(f"1D Array       : {a}")
print(f"Type           : {type(a)}")
print(f"Data type      : {a.dtype}")
print(f"Shape          : {a.shape}")
print(f"Size           : {a.size}")

b = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(f"\n2D Array:\n{b}")
print(f"Shape          : {b.shape}")

print(f"\nzeros(3,3):\n{np.zeros((3,3))}")
print(f"\nones(2,4):\n{np.ones((2,4))}")
print(f"\narange(0,10,2): {np.arange(0, 10, 2)}")
print(f"linspace(0,1,5): {np.linspace(0, 1, 5)}")
print(f"eye(3):\n{np.eye(3)}")

# ── Indexing & Slicing ────────────────────────────
print("\n=== Indexing & Slicing ===")
arr = np.array([10, 20, 30, 40, 50, 60])
print(f"Array          : {arr}")
print(f"arr[0]         : {arr[0]}")
print(f"arr[-1]        : {arr[-1]}")
print(f"arr[1:4]       : {arr[1:4]}")
print(f"arr[::2]       : {arr[::2]}")

print(f"\n2D array:\n{b}")
print(f"b[0]           : {b[0]}")
print(f"b[1][2]        : {b[1][2]}")
print(f"b[:, 1]        : {b[:, 1]}")  # second column
print(f"b[0:2, 1:3]:\n{b[0:2, 1:3]}")

# ── Arithmetic Operations ─────────────────────────
print("\n=== Arithmetic Operations ===")
x = np.array([1, 2, 3, 4])
y = np.array([10, 20, 30, 40])

print(f"x         : {x}")
print(f"y         : {y}")
print(f"x + y     : {x + y}")
print(f"y - x     : {y - x}")
print(f"x * y     : {x * y}")
print(f"y / x     : {y / x}")
print(f"x ** 2    : {x ** 2}")
print(f"sqrt(x)   : {np.sqrt(x)}")

print(f"\nSum       : {np.sum(y)}")
print(f"Mean      : {np.mean(y)}")
print(f"Std dev   : {np.std(y):.2f}")
print(f"Min       : {np.min(y)}")
print(f"Max       : {np.max(y)}")
