# Q9. Demonstrate use of break, continue, and pass in loops.

# ── break ─────────────────────────────────────────
print("=== break: Stop loop when number is 5 ===")
for i in range(1, 11):
    if i == 5:
        print(f"  Breaking at {i}!")
        break
    print(f"  i = {i}")

# ── continue ──────────────────────────────────────
print("\n=== continue: Skip even numbers ===")
for i in range(1, 11):
    if i % 2 == 0:
        continue  # skip even numbers
    print(f"  i = {i}")

# ── pass ──────────────────────────────────────────
print("\n=== pass: Placeholder in loop ===")
for i in range(1, 6):
    if i == 3:
        pass  # do nothing, just a placeholder
        print(f"  i = {i} (pass was used here, nothing happened)")
    else:
        print(f"  i = {i}")
