# Q13. Write a program to perform tuple operations and demonstrate immutability.

t = (10, 20, 30, 40, 50, 20, 30)
print(f"Tuple: {t}")

# ── Tuple Operations ──────────────────────────────
print("\n=== Tuple Operations ===")
print(f"Length             : {len(t)}")
print(f"First element      : {t[0]}")
print(f"Last element       : {t[-1]}")
print(f"Slicing [1:4]      : {t[1:4]}")
print(f"Count of 20        : {t.count(20)}")
print(f"Index of 30        : {t.index(30)}")
print(f"Min value          : {min(t)}")
print(f"Max value          : {max(t)}")
print(f"Sum                : {sum(t)}")

# ── Tuple Packing & Unpacking ─────────────────────
print("\n=== Tuple Packing & Unpacking ===")
packed = (1, 2, 3)
a, b, c = packed
print(f"Packed tuple       : {packed}")
print(f"Unpacked values    : a={a}, b={b}, c={c}")

# ── Tuple Concatenation ───────────────────────────
t1 = (1, 2, 3)
t2 = (4, 5, 6)
t3 = t1 + t2
print(f"\nConcatenation      : {t1} + {t2} = {t3}")

# ── Immutability Demo ─────────────────────────────
print("\n=== Immutability Demo ===")
print("Trying to change t[0] = 99 ...")
try:
    t[0] = 99
except TypeError as e:
    print(f"Error: {e}")
    print("Tuples are IMMUTABLE — cannot be changed after creation!")
