# Q4. Write a program using if-else to find the largest of three numbers.

a = float(input("Enter first number : "))
b = float(input("Enter second number: "))
c = float(input("Enter third number : "))

print("\n=== Finding Largest Number ===")
if a >= b and a >= c:
    print(f"Largest number is: {a}")
elif b >= a and b >= c:
    print(f"Largest number is: {b}")
else:
    print(f"Largest number is: {c}")
