# Q6. Write a program using for loop to print multiplication table of a number.

num = int(input("Enter a number: "))
limit = int(input("Enter table limit (e.g. 10): "))

print(f"\n=== Multiplication Table of {num} ===")
for i in range(1, limit + 1):
    print(f"{num} x {i:2} = {num * i}")
