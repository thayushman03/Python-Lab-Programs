# Q8. Write a program using while loop to compute sum of first N natural numbers.

n = int(input("Enter value of N: "))

total = 0
i = 1

print(f"\n=== Sum of First {n} Natural Numbers ===")
while i <= n:
    total += i
    i += 1

print(f"Sum = 1 + 2 + ... + {n} = {total}")

# Verify using formula: n*(n+1)/2
formula_result = n * (n + 1) // 2
print(f"Verification using formula n*(n+1)/2 = {formula_result}")
