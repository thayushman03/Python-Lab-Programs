# Q24. Write a program to handle exceptions using try-except blocks.

print("=== Exception Handling Examples ===\n")

# ── 1. ZeroDivisionError ──────────────────────────
print("--- 1. ZeroDivisionError ---")
try:
    a = int(input("Enter numerator  : "))
    b = int(input("Enter denominator: "))
    result = a / b
    print(f"Result: {a} / {b} = {result}")
except ZeroDivisionError:
    print("Error: Cannot divide by zero!")
except ValueError:
    print("Error: Please enter valid integers!")

# ── 2. ValueError ─────────────────────────────────
print("\n--- 2. ValueError ---")
try:
    age = int(input("Enter your age: "))
    if age < 0:
        raise ValueError("Age cannot be negative!")
    print(f"Your age is: {age}")
except ValueError as e:
    print(f"Error: {e}")

# ── 3. IndexError ─────────────────────────────────
print("\n--- 3. IndexError ---")
try:
    lst = [10, 20, 30]
    idx = int(input(f"Enter index (list has {len(lst)} items): "))
    print(f"Element at index {idx}: {lst[idx]}")
except IndexError:
    print("Error: Index out of range!")
except ValueError:
    print("Error: Please enter a valid integer index!")

# ── 4. FileNotFoundError ──────────────────────────
print("\n--- 4. FileNotFoundError ---")
try:
    with open("nonexistent_file.txt", "r") as f:
        content = f.read()
except FileNotFoundError:
    print("Error: File not found!")

# ── 5. KeyError ───────────────────────────────────
print("\n--- 5. KeyError ---")
try:
    d = {"name": "Ayushman", "roll": "Y24170523"}
    key = input("Enter key to search (e.g. name, roll, age): ")
    print(f"Value: {d[key]}")
except KeyError as e:
    print(f"Error: Key {e} not found in dictionary!")
