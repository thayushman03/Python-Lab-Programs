# 🐍 Python Programming Lab — BCA IV Semester

All 31 Python lab programs as per the syllabus.

**Student:** Ayushman Singh
**Roll No:** Y24170523
**Course:** BCA IV Semester

---

## 📋 Program List

| No. | File | Topic |
|-----|------|-------|
| Q01 | Q01_numeric_datatypes.py | Numeric data types and type conversion |
| Q02 | Q02_arithmetic_operations.py | Arithmetic operations on user input |
| Q03 | Q03_variable_swapping.py | Variable assignment and swapping |
| Q04 | Q04_largest_of_three.py | Largest of three numbers using if-else |
| Q05 | Q05_classify_number.py | Classify number using nested if |
| Q06 | Q06_multiplication_table.py | Multiplication table using for loop |
| Q07 | Q07_iterate_collections.py | Iterate through string, list, dictionary |
| Q08 | Q08_sum_natural_numbers.py | Sum of N natural numbers using while |
| Q09 | Q09_break_continue_pass.py | break, continue, pass in loops |
| Q10 | Q10_string_operations.py | String operations (slicing, concatenation, reversing) |
| Q11 | Q11_character_frequency.py | Count frequency of characters in a string |
| Q12 | Q12_list_operations.py | List slicing and manipulation |
| Q13 | Q13_tuple_operations.py | Tuple operations and immutability |
| Q14 | Q14_dictionary_operations.py | Dictionary operations (add, update, delete) |
| Q15 | Q15_builtin_functions.py | Built-in functions on list, string, dictionary |
| Q16 | Q16_functions.py | Functions for string and list operations |
| Q17 | Q17_file_reading.py | File reading using read(), readline(), readlines() |
| Q18 | Q18_file_write_append.py | Write and append data to a file |
| Q19 | Q19_file_copy.py | Copy contents of one file to another |
| Q20 | Q20_file_seek.py | File pointer operations using seek() |
| Q21 | Q21_database_connect.py | Connect to database and create table |
| Q22 | Q22_database_crud.py | INSERT, UPDATE, DELETE, SELECT operations |
| Q23 | Q23_transaction_control.py | Transaction control (commit and rollback) |
| Q24 | Q24_exception_handling.py | Exception handling using try-except |
| Q25 | Q25_multiple_exceptions.py | Multiple exception handling |
| Q26 | Q26_custom_exceptions.py | finally and custom exceptions |
| Q27 | Q27_numpy_operations.py | NumPy array operations |
| Q28 | Q28_pandas_csv.py | Pandas — read CSV and basic analysis |
| Q29 | Q29_pandas_filter_group.py | Pandas — filter and group data |
| Q30 | Q30_matplotlib_graphs.py | Matplotlib — line and bar graphs |
| Q31 | Q31_numpy_pandas_matplotlib.py | NumPy + Pandas + Matplotlib combined |

---

## 🚀 How to Run

```bash
# Run any program
python Q01_numeric_datatypes.py

# For Q27-Q31, install required libraries first:
pip install numpy pandas matplotlib
```

---

## 📦 Requirements

- Python 3.7+
- numpy
- pandas
- matplotlib
- sqlite3 (built-in)
