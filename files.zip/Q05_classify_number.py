# Q5. Write a program using nested if to classify a number (positive, negative, zero).

num = float(input("Enter a number: "))

print("\n=== Number Classification ===")
if num > 0:
    print(f"{num} is a Positive number.")
    if num % 2 == 0:
        print("It is also an Even number.")
    else:
        print("It is also an Odd number.")
elif num < 0:
    print(f"{num} is a Negative number.")
    if num % 2 == 0:
        print("It is also an Even number.")
    else:
        print("It is also an Odd number.")
else:
    print("The number is Zero.")
