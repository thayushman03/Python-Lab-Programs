# Q2. Write a program to perform all arithmetic operations on user input numbers.

a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

print("\n=== Arithmetic Operations ===")
print(f"Addition       : {a} + {b} = {a + b}")
print(f"Subtraction    : {a} - {b} = {a - b}")
print(f"Multiplication : {a} * {b} = {a * b}")

if b != 0:
    print(f"Division       : {a} / {b} = {a / b}")
    print(f"Floor Division : {a} // {b} = {a // b}")
    print(f"Modulus        : {a} % {b} = {a % b}")
else:
    print("Division       : Cannot divide by zero!")
    print("Floor Division : Cannot divide by zero!")
    print("Modulus        : Cannot divide by zero!")

print(f"Exponentiation : {a} ** {b} = {a ** b}")
