# Q26. Write a program using finally and custom exceptions.

# ── Custom Exception Classes ──────────────────────

class AgeError(Exception):
    """Raised when age is invalid."""
    def __init__(self, age, message="Invalid age entered"):
        self.age = age
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f"{self.message}: {self.age}"


class MarksError(Exception):
    """Raised when marks are out of valid range."""
    def __init__(self, marks, message="Marks must be between 0 and 100"):
        self.marks = marks
        self.message = message
        super().__init__(self.message)

    def __str__(self):
        return f"{self.message}. Got: {self.marks}"


class InsufficientFundsError(Exception):
    """Raised when bank balance is insufficient."""
    def __init__(self, amount, balance):
        self.amount  = amount
        self.balance = balance
        super().__init__(f"Cannot withdraw ₹{amount}. Available balance: ₹{balance}")


# ── Demo 1: Custom AgeError + finally ─────────────
print("=== Demo 1: Custom AgeError ===")
try:
    age = int(input("Enter age: "))
    if age < 0 or age > 150:
        raise AgeError(age, "Age must be between 0 and 150")
    print(f"Valid age: {age}")
except AgeError as e:
    print(f"AgeError caught: {e}")
except ValueError:
    print("Please enter a valid integer!")
finally:
    print("Age validation complete.\n")

# ── Demo 2: Custom MarksError + finally ───────────
print("=== Demo 2: Custom MarksError ===")
try:
    marks = float(input("Enter marks (0-100): "))
    if not (0 <= marks <= 100):
        raise MarksError(marks)
    print(f"Valid marks: {marks}")
except MarksError as e:
    print(f"MarksError caught: {e}")
except ValueError:
    print("Please enter a valid number!")
finally:
    print("Marks validation complete.\n")

# ── Demo 3: Custom InsufficientFundsError ─────────
print("=== Demo 3: Bank Withdrawal ===")
balance = 5000
try:
    amount = float(input("Enter withdrawal amount: "))
    if amount > balance:
        raise InsufficientFundsError(amount, balance)
    balance -= amount
    print(f"Withdrawal successful! Remaining balance: ₹{balance}")
except InsufficientFundsError as e:
    print(f"Transaction failed: {e}")
except ValueError:
    print("Invalid amount entered!")
finally:
    print("Transaction process ended.")
