# Q15. Write a program using built-in functions on list, string, and dictionary.

# ── Built-in functions on List ────────────────────
print("=== Built-in Functions on List ===")
nums = [5, 2, 8, 1, 9, 3, 7, 4, 6]
print(f"List    : {nums}")
print(f"len()   : {len(nums)}")
print(f"max()   : {max(nums)}")
print(f"min()   : {min(nums)}")
print(f"sum()   : {sum(nums)}")
print(f"sorted(): {sorted(nums)}")
print(f"sorted(reverse=True): {sorted(nums, reverse=True)}")
print(f"list(range(1,6)): {list(range(1, 6))}")
print(f"enumerate: {list(enumerate(nums[:3]))}")

# ── Built-in functions on String ──────────────────
print("\n=== Built-in Functions on String ===")
s = "  Hello, Python World!  "
print(f"String  : '{s}'")
print(f"len()   : {len(s)}")
print(f"upper() : {s.upper()}")
print(f"lower() : {s.lower()}")
print(f"strip() : '{s.strip()}'")
print(f"split() : {s.strip().split()}")
print(f"replace(): {s.replace('Python', 'BCA')}")
print(f"find()  : {s.find('Python')}")
print(f"count() : {s.count('l')}")
print(f"join()  : {'-'.join(['A', 'B', 'C'])}")

# ── Built-in functions on Dictionary ─────────────
print("\n=== Built-in Functions on Dictionary ===")
d = {"math": 90, "science": 85, "english": 78, "hindi": 92}
print(f"Dict    : {d}")
print(f"len()   : {len(d)}")
print(f"keys()  : {list(d.keys())}")
print(f"values(): {list(d.values())}")
print(f"items() : {list(d.items())}")
print(f"max value: {max(d.values())}")
print(f"min value: {min(d.values())}")
print(f"sum of values: {sum(d.values())}")
print(f"sorted keys: {sorted(d.keys())}")
