# Q12. Write a program to demonstrate list slicing and list manipulation.

numbers = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
print(f"Original list: {numbers}")

# ── Slicing ───────────────────────────────────────
print("\n=== List Slicing ===")
print(f"First 3 elements   : {numbers[:3]}")
print(f"Last 3 elements    : {numbers[-3:]}")
print(f"Elements 3 to 6    : {numbers[2:6]}")
print(f"Every 2nd element  : {numbers[::2]}")
print(f"Reversed list      : {numbers[::-1]}")

# ── Manipulation ──────────────────────────────────
print("\n=== List Manipulation ===")

# append
numbers.append(110)
print(f"After append(110)  : {numbers}")

# insert
numbers.insert(0, 5)
print(f"After insert(0, 5) : {numbers}")

# remove
numbers.remove(5)
print(f"After remove(5)    : {numbers}")

# pop
popped = numbers.pop()
print(f"After pop()        : {numbers} (popped: {popped})")

# sort
mixed = [3, 1, 4, 1, 5, 9, 2, 6]
mixed.sort()
print(f"Sorted list        : {mixed}")

mixed.sort(reverse=True)
print(f"Reverse sorted     : {mixed}")

# count and index
lst = [1, 2, 3, 2, 4, 2]
print(f"\nCount of 2 in {lst}: {lst.count(2)}")
print(f"Index of 3 in {lst}: {lst.index(3)}")

# extend
a = [1, 2, 3]
b = [4, 5, 6]
a.extend(b)
print(f"After extend       : {a}")
