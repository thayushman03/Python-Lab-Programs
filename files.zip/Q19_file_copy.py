# Q19. Write a program to copy contents of one file to another.

source_file = "source.txt"
destination_file = "destination.txt"

# Create a source file first
with open(source_file, "w") as f:
    f.write("This is the source file.\n")
    f.write("It contains some sample data.\n")
    f.write("We will copy this to another file.\n")
    f.write("BCA IV Semester - Python Lab.\n")

print(f"Source file '{source_file}' created.")

# ── Copy contents ─────────────────────────────────
print(f"\nCopying '{source_file}' to '{destination_file}'...")

with open(source_file, "r") as src:
    content = src.read()

with open(destination_file, "w") as dst:
    dst.write(content)

print("Copy successful!")

# ── Verify ────────────────────────────────────────
print(f"\n=== Contents of '{destination_file}' ===")
with open(destination_file, "r") as f:
    print(f.read())

# Count lines copied
line_count = content.count("\n")
print(f"Total lines copied: {line_count}")
