# Q20. Write a program to demonstrate file pointer operations using seek().

filename = "pointer_demo.txt"

# Create file
with open(filename, "w") as f:
    f.write("Hello, Python World!\n")
    f.write("File pointer demo.\n")
    f.write("BCA IV Semester.\n")

print(f"File '{filename}' created.\n")

# ── seek() and tell() demo ────────────────────────
with open(filename, "r") as f:

    # Read first 5 characters
    print("=== Read first 5 characters ===")
    print(f.read(5))

    # Current position
    print(f"\nCurrent position (tell()): {f.tell()}")

    # Go back to beginning
    print("\n=== seek(0) — Go to beginning ===")
    f.seek(0)
    print(f"Position after seek(0): {f.tell()}")
    print(f"Read from start: {f.read(12)}")

    # Go to specific position
    print("\n=== seek(7) — Go to position 7 ===")
    f.seek(7)
    print(f"Read from position 7: {f.read(6)}")

    # Go to end
    print("\n=== seek(0, 2) — Go to end of file ===")
    f.seek(0, 2)
    print(f"Position at end of file: {f.tell()}")

    # Read full file from start
    print("\n=== Full file content ===")
    f.seek(0)
    print(f.read())
