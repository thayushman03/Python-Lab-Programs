# Q23. Demonstrate transaction control (commit and rollback) in database operations.

import sqlite3

DB_NAME = "bank.db"

conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

# Create accounts table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS accounts (
        id      INTEGER PRIMARY KEY,
        name    TEXT    NOT NULL,
        balance REAL    NOT NULL
    )
""")
conn.commit()

# Insert sample accounts
cursor.execute("DELETE FROM accounts")
cursor.executemany(
    "INSERT INTO accounts (id, name, balance) VALUES (?, ?, ?)",
    [(1, "Ayushman", 5000.0), (2, "Rahul", 3000.0)]
)
conn.commit()

def show_balances():
    cursor.execute("SELECT * FROM accounts")
    for row in cursor.fetchall():
        print(f"  {row[1]:<15}: ₹{row[2]:.2f}")

print("=== Initial Balances ===")
show_balances()

# ── Successful Transaction (COMMIT) ───────────────
print("\n=== Transaction 1: Transfer ₹1000 (COMMIT) ===")
try:
    conn.execute("BEGIN")
    cursor.execute("UPDATE accounts SET balance = balance - 1000 WHERE id = 1")
    cursor.execute("UPDATE accounts SET balance = balance + 1000 WHERE id = 2")
    conn.commit()
    print("  Transaction committed successfully!")
except Exception as e:
    conn.rollback()
    print(f"  Error! Rolled back: {e}")

show_balances()

# ── Failed Transaction (ROLLBACK) ─────────────────
print("\n=== Transaction 2: Transfer ₹10000 (ROLLBACK) ===")
try:
    conn.execute("BEGIN")
    cursor.execute("SELECT balance FROM accounts WHERE id = 1")
    balance = cursor.fetchone()[0]

    amount = 10000
    if balance < amount:
        raise ValueError(f"Insufficient funds! Available: ₹{balance}")

    cursor.execute("UPDATE accounts SET balance = balance - ? WHERE id = 1", (amount,))
    cursor.execute("UPDATE accounts SET balance = balance + ? WHERE id = 2", (amount,))
    conn.commit()
except Exception as e:
    conn.rollback()
    print(f"  Transaction ROLLED BACK! Reason: {e}")

print("\n=== Final Balances (after rollback, unchanged) ===")
show_balances()

conn.close()
