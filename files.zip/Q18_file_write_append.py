# Q18. Write a program to write and append data to a file.

filename = "students.txt"

# ── Write mode (creates new / overwrites) ─────────
print("=== Writing to file ===")
with open(filename, "w") as f:
    f.write("Student Records\n")
    f.write("=" * 30 + "\n")
    f.write("1. Ayushman Singh - Y24170523\n")
    f.write("2. Rahul Kumar    - Y24170524\n")
    f.write("3. Priya Sharma   - Y24170525\n")

print(f"Data written to '{filename}'")

# Show file contents
with open(filename, "r") as f:
    print(f.read())

# ── Append mode (adds to existing file) ───────────
print("=== Appending to file ===")
with open(filename, "a") as f:
    f.write("4. Anjali Verma   - Y24170526\n")
    f.write("5. Mohit Singh    - Y24170527\n")

print(f"Data appended to '{filename}'")

# Show updated file contents
print("\n=== Updated file contents ===")
with open(filename, "r") as f:
    print(f.read())
