# Q17. Write a program to read contents of a file using read(), readline(), and readlines().

# First create a sample file to read
sample_file = "sample.txt"

with open(sample_file, "w") as f:
    f.write("Line 1: Hello, Python!\n")
    f.write("Line 2: File handling is important.\n")
    f.write("Line 3: BCA IV Semester.\n")
    f.write("Line 4: Ayushman Singh.\n")
    f.write("Line 5: End of file.\n")

print(f"Sample file '{sample_file}' created.\n")

# ── read() — reads entire file as one string ──────
print("=== Using read() ===")
with open(sample_file, "r") as f:
    content = f.read()
print(content)

# ── readline() — reads one line at a time ─────────
print("=== Using readline() ===")
with open(sample_file, "r") as f:
    line = f.readline()
    while line:
        print(f"  -> {line}", end="")
        line = f.readline()
print()

# ── readlines() — reads all lines as a list ───────
print("\n=== Using readlines() ===")
with open(sample_file, "r") as f:
    lines = f.readlines()

print(f"Total lines: {len(lines)}")
for i, line in enumerate(lines, 1):
    print(f"  Line {i}: {line.strip()}")
