# Q22. Write a program to perform INSERT, UPDATE, DELETE, and SELECT operations.

import sqlite3

DB_NAME = "school.db"

conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()

# Create table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id     INTEGER PRIMARY KEY AUTOINCREMENT,
        name   TEXT    NOT NULL,
        roll   TEXT    UNIQUE NOT NULL,
        marks  REAL    NOT NULL
    )
""")
conn.commit()

def show_all():
    cursor.execute("SELECT * FROM students")
    rows = cursor.fetchall()
    if not rows:
        print("  (No records found)")
        return
    print(f"  {'ID':<5} {'Name':<20} {'Roll':<12} {'Marks'}")
    print("  " + "-" * 45)
    for row in rows:
        print(f"  {row[0]:<5} {row[1]:<20} {row[2]:<12} {row[3]}")

# ── INSERT ────────────────────────────────────────
print("=== INSERT Records ===")
students = [
    ("Ayushman Singh", "Y24170523", 90),
    ("Rahul Kumar",    "Y24170524", 75),
    ("Priya Sharma",   "Y24170525", 88),
    ("Anjali Verma",   "Y24170526", 65),
]
cursor.executemany(
    "INSERT OR IGNORE INTO students (name, roll, marks) VALUES (?, ?, ?)",
    students
)
conn.commit()
print(f"  {cursor.rowcount if cursor.rowcount > 0 else len(students)} records inserted.")
show_all()

# ── SELECT ────────────────────────────────────────
print("\n=== SELECT — Students with marks > 80 ===")
cursor.execute("SELECT * FROM students WHERE marks > 80 ORDER BY marks DESC")
rows = cursor.fetchall()
for row in rows:
    print(f"  {row[1]} — {row[3]} marks")

# ── UPDATE ────────────────────────────────────────
print("\n=== UPDATE — Set Rahul's marks to 85 ===")
cursor.execute("UPDATE students SET marks = 85 WHERE roll = 'Y24170524'")
conn.commit()
print(f"  {cursor.rowcount} record(s) updated.")
show_all()

# ── DELETE ────────────────────────────────────────
print("\n=== DELETE — Remove Anjali ===")
cursor.execute("DELETE FROM students WHERE roll = 'Y24170526'")
conn.commit()
print(f"  {cursor.rowcount} record(s) deleted.")
show_all()

conn.close()
print("\nDone.")
