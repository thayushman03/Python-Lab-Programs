# Q29. Write a program using pandas to filter and group data.

import pandas as pd

# ── Create sample data ────────────────────────────
data = {
    "Name"      : ["Ayushman", "Rahul", "Priya", "Anjali", "Mohit", "Sneha", "Vikram", "Riya"],
    "Department": ["BCA", "BCA", "BCA", "BSc", "BSc", "BCA", "BSc", "BSc"],
    "Math"      : [90, 75, 88, 65, 72, 95, 80, 55],
    "Science"   : [85, 70, 92, 60, 68, 88, 78, 62],
    "English"   : [78, 80, 75, 70, 65, 82, 88, 71],
    "Gender"    : ["M", "M", "F", "F", "M", "F", "M", "F"]
}

df = pd.DataFrame(data)
df["Total"]   = df["Math"] + df["Science"] + df["English"]
df["Average"] = df["Total"] / 3

print("=== Full Dataset ===")
print(df.to_string(index=False))

# ── Filtering ─────────────────────────────────────
print("\n=== Filter: Math > 80 ===")
high_math = df[df["Math"] > 80]
print(high_math[["Name", "Department", "Math"]].to_string(index=False))

print("\n=== Filter: BCA Department ===")
bca = df[df["Department"] == "BCA"]
print(bca[["Name", "Math", "Science", "English", "Total"]].to_string(index=False))

print("\n=== Filter: Female students with Average > 75 ===")
filtered = df[(df["Gender"] == "F") & (df["Average"] > 75)]
print(filtered[["Name", "Gender", "Average"]].to_string(index=False))

# ── Grouping ──────────────────────────────────────
print("\n=== Group by Department — Average marks ===")
grouped = df.groupby("Department")[["Math", "Science", "English", "Average"]].mean()
print(grouped.round(2))

print("\n=== Group by Department — Count ===")
print(df.groupby("Department")["Name"].count())

print("\n=== Group by Gender — Total average ===")
print(df.groupby("Gender")["Average"].mean().round(2))

print("\n=== Group by Department — Max marks ===")
print(df.groupby("Department")[["Math", "Science", "English"]].max())
