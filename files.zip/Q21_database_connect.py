# Q21. Write a program to connect to a database and create a table.

import sqlite3

DB_NAME = "school.db"

# ── Connect to database ───────────────────────────
print("=== Connecting to SQLite Database ===")
conn = sqlite3.connect(DB_NAME)
cursor = conn.cursor()
print(f"Connected to '{DB_NAME}' successfully!")

# ── Create table ──────────────────────────────────
print("\n=== Creating 'students' table ===")
cursor.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id       INTEGER PRIMARY KEY AUTOINCREMENT,
        name     TEXT    NOT NULL,
        roll     TEXT    UNIQUE NOT NULL,
        course   TEXT    NOT NULL,
        marks    REAL    NOT NULL,
        grade    TEXT    NOT NULL
    )
""")
conn.commit()
print("Table 'students' created successfully!")

# ── Verify table ──────────────────────────────────
print("\n=== Table Info ===")
cursor.execute("PRAGMA table_info(students)")
columns = cursor.fetchall()
print(f"{'Col ID':<8} {'Name':<10} {'Type':<10} {'Not Null':<10} {'Primary Key'}")
print("-" * 55)
for col in columns:
    print(f"{col[0]:<8} {col[1]:<10} {col[2]:<10} {col[3]:<10} {col[5]}")

# ── Show all tables in DB ─────────────────────────
print("\n=== Tables in Database ===")
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = cursor.fetchall()
for table in tables:
    print(f"  - {table[0]}")

conn.close()
print("\nDatabase connection closed.")
