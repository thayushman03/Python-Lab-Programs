# Q30. Write a program using matplotlib to plot line and bar graphs.

import matplotlib.pyplot as plt
import numpy as np

# ── Data ──────────────────────────────────────────
students = ["Ayushman", "Rahul", "Priya", "Anjali", "Mohit", "Sneha"]
math     = [90, 75, 88, 65, 72, 95]
science  = [85, 70, 92, 60, 68, 88]
english  = [78, 80, 75, 70, 65, 82]

# ── Figure with 2 subplots ────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("Student Performance Analysis", fontsize=16, fontweight='bold')

# ── Line Graph ────────────────────────────────────
ax1 = axes[0]
ax1.plot(students, math,    marker='o', color='blue',   label='Math',    linewidth=2)
ax1.plot(students, science, marker='s', color='green',  label='Science', linewidth=2)
ax1.plot(students, english, marker='^', color='red',    label='English', linewidth=2)

ax1.set_title("Marks Comparison — Line Graph")
ax1.set_xlabel("Students")
ax1.set_ylabel("Marks")
ax1.set_ylim(0, 110)
ax1.legend()
ax1.grid(True, linestyle='--', alpha=0.7)
ax1.tick_params(axis='x', rotation=30)

# ── Bar Graph ─────────────────────────────────────
ax2 = axes[1]
x = np.arange(len(students))
width = 0.25

bars1 = ax2.bar(x - width, math,    width, label='Math',    color='blue',  alpha=0.8)
bars2 = ax2.bar(x,         science, width, label='Science', color='green', alpha=0.8)
bars3 = ax2.bar(x + width, english, width, label='English', color='red',   alpha=0.8)

ax2.set_title("Marks Comparison — Bar Graph")
ax2.set_xlabel("Students")
ax2.set_ylabel("Marks")
ax2.set_ylim(0, 115)
ax2.set_xticks(x)
ax2.set_xticklabels(students, rotation=30)
ax2.legend()
ax2.grid(True, axis='y', linestyle='--', alpha=0.7)

# Add value labels on bars
for bar in bars1:
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
             str(int(bar.get_height())), ha='center', va='bottom', fontsize=7)

plt.tight_layout()
plt.savefig("student_performance.png", dpi=100, bbox_inches='tight')
print("Graph saved as 'student_performance.png'")
plt.show()
