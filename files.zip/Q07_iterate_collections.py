# Q7. Write a program to iterate through string, list, and dictionary using loops.

# ── Iterating through a String ────────────────────
print("=== Iterating through a String ===")
text = "Python"
for char in text:
    print(f"  Character: {char}")

# ── Iterating through a List ──────────────────────
print("\n=== Iterating through a List ===")
fruits = ["Apple", "Banana", "Cherry", "Mango"]
for i, fruit in enumerate(fruits):
    print(f"  Index {i}: {fruit}")

# ── Iterating through a Dictionary ────────────────
print("\n=== Iterating through a Dictionary ===")
student = {
    "name"   : "Ayushman Singh",
    "roll"   : "Y24170523",
    "course" : "BCA",
    "semester": "IV"
}

# Keys only
print("  Keys:")
for key in student.keys():
    print(f"    {key}")

# Values only
print("  Values:")
for value in student.values():
    print(f"    {value}")

# Key-Value pairs
print("  Key-Value Pairs:")
for key, value in student.items():
    print(f"    {key} : {value}")
