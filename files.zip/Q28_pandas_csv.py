# Q28. Write a program using pandas to read a CSV file and perform basic analysis.

import pandas as pd
import os

# ── Create sample CSV file ────────────────────────
csv_file = "students_data.csv"

data = {
    "Name"    : ["Ayushman", "Rahul", "Priya", "Anjali", "Mohit", "Sneha", "Vikram"],
    "Roll"    : ["Y001", "Y002", "Y003", "Y004", "Y005", "Y006", "Y007"],
    "Math"    : [90, 75, 88, 65, 72, 95, 80],
    "Science" : [85, 70, 92, 60, 68, 88, 78],
    "English" : [78, 80, 75, 70, 65, 82, 88],
    "Age"     : [20, 21, 20, 22, 21, 20, 23],
    "Gender"  : ["M", "M", "F", "F", "M", "F", "M"]
}

df_sample = pd.DataFrame(data)
df_sample.to_csv(csv_file, index=False)
print(f"Sample CSV '{csv_file}' created.\n")

# ── Read CSV ──────────────────────────────────────
df = pd.read_csv(csv_file)

print("=== Basic Info ===")
print(f"Shape (rows, cols): {df.shape}")
print(f"Columns: {list(df.columns)}")
print(f"\nData Types:\n{df.dtypes}")

print("\n=== First 5 rows (head) ===")
print(df.head())

print("\n=== Last 3 rows (tail) ===")
print(df.tail(3))

print("\n=== Statistical Summary ===")
print(df.describe())

print("\n=== Column-wise Analysis ===")
print(f"Average Math marks   : {df['Math'].mean():.2f}")
print(f"Highest Math marks   : {df['Math'].max()}")
print(f"Lowest Math marks    : {df['Math'].min()}")
print(f"Total students       : {len(df)}")

print("\n=== Null Values Check ===")
print(df.isnull().sum())

print("\n=== Value Counts (Gender) ===")
print(df['Gender'].value_counts())
