# Q1. Write a program to demonstrate different numeric data types
# (int, float) and type conversion.

# ── Integer ──────────────────────────────────────
a = 10
b = -25
c = 0

print("=== Integer Examples ===")
print(f"a = {a}, type = {type(a)}")
print(f"b = {b}, type = {type(b)}")
print(f"c = {c}, type = {type(c)}")

# ── Float ─────────────────────────────────────────
x = 3.14
y = -2.5
z = 1.0

print("\n=== Float Examples ===")
print(f"x = {x}, type = {type(x)}")
print(f"y = {y}, type = {type(y)}")
print(f"z = {z}, type = {type(z)}")

# ── Type Conversion ───────────────────────────────
print("\n=== Type Conversion ===")

# int to float
i = 5
f = float(i)
print(f"int to float: {i} → {f}, type = {type(f)}")

# float to int (truncates decimal)
pi = 3.99
i2 = int(pi)
print(f"float to int: {pi} → {i2}, type = {type(i2)}")

# int to string
s = str(100)
print(f"int to string: 100 → '{s}', type = {type(s)}")

# string to int
s2 = "42"
i3 = int(s2)
print(f"string to int: '{s2}' → {i3}, type = {type(i3)}")

# string to float
s3 = "3.14"
f2 = float(s3)
print(f"string to float: '{s3}' → {f2}, type = {type(f2)}")
