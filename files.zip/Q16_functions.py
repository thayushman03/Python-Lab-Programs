# Q16. Write functions to organize a program that performs basic operations
# on strings and lists.

# ── String Functions ──────────────────────────────

def reverse_string(s):
    """Returns the reverse of a string."""
    return s[::-1]

def count_vowels(s):
    """Counts vowels in a string."""
    return sum(1 for c in s.lower() if c in 'aeiou')

def is_palindrome(s):
    """Checks if a string is a palindrome."""
    cleaned = s.lower().replace(" ", "")
    return cleaned == cleaned[::-1]

def capitalize_words(s):
    """Capitalizes first letter of each word."""
    return s.title()

# ── List Functions ────────────────────────────────

def find_max(lst):
    """Finds maximum element in a list."""
    return max(lst)

def find_min(lst):
    """Finds minimum element in a list."""
    return min(lst)

def calculate_average(lst):
    """Calculates average of a list."""
    return sum(lst) / len(lst)

def remove_duplicates(lst):
    """Removes duplicates from a list."""
    return list(set(lst))

def flatten_list(nested):
    """Flattens a nested list."""
    return [item for sublist in nested for item in sublist]


# ── Main Program ──────────────────────────────────

if __name__ == "__main__":

    # String operations
    print("=== String Function Demonstrations ===")
    text = "racecar"
    print(f"String          : '{text}'")
    print(f"Reversed        : '{reverse_string(text)}'")
    print(f"Vowel count     : {count_vowels(text)}")
    print(f"Is palindrome?  : {is_palindrome(text)}")
    print(f"Capitalize words: '{capitalize_words('hello world python')}'")

    # List operations
    print("\n=== List Function Demonstrations ===")
    numbers = [4, 2, 7, 1, 9, 3, 7, 4, 6, 2]
    print(f"List            : {numbers}")
    print(f"Maximum         : {find_max(numbers)}")
    print(f"Minimum         : {find_min(numbers)}")
    print(f"Average         : {calculate_average(numbers):.2f}")
    print(f"No duplicates   : {sorted(remove_duplicates(numbers))}")

    nested = [[1, 2, 3], [4, 5], [6, 7, 8]]
    print(f"Flattened {nested}: {flatten_list(nested)}")
