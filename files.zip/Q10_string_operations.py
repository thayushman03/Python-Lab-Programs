# Q10. Write a program to perform string operations (slicing, concatenation, reversing).

s = input("Enter a string: ")

print(f"\n=== String Operations on '{s}' ===")

# Length
print(f"Length              : {len(s)}")

# Upper and Lower
print(f"Uppercase           : {s.upper()}")
print(f"Lowercase           : {s.lower()}")

# Slicing
print(f"First 3 characters  : {s[:3]}")
print(f"Last 3 characters   : {s[-3:]}")
print(f"Middle portion      : {s[2:-2]}")
print(f"Every 2nd character : {s[::2]}")

# Reversing
print(f"Reversed            : {s[::-1]}")

# Concatenation
s2 = " Python"
print(f"Concatenation       : '{s}' + '{s2}' = '{s + s2}'")

# Repetition
print(f"Repeated 3 times    : {s * 3}")

# Find and Replace
print(f"Replace first char  : {s.replace(s[0], '*', 1)}")

# Check methods
print(f"Is alphabetic?      : {s.isalpha()}")
print(f"Starts with '{s[0]}'?  : {s.startswith(s[0])}")
print(f"Ends with '{s[-1]}'?   : {s.endswith(s[-1])}")
