# Q31. Write a program combining numpy, pandas, and matplotlib for simple data analysis.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ── Step 1: Create data using NumPy ───────────────
print("=== Step 1: Generating Data with NumPy ===")
np.random.seed(42)

names    = ["Ayushman", "Rahul", "Priya", "Anjali", "Mohit", "Sneha", "Vikram", "Riya"]
math     = np.random.randint(50, 100, size=8)
science  = np.random.randint(50, 100, size=8)
english  = np.random.randint(50, 100, size=8)

print(f"Math scores    : {math}")
print(f"Science scores : {science}")
print(f"English scores : {english}")

# ── Step 2: Analyze with Pandas ───────────────────
print("\n=== Step 2: Analysis with Pandas ===")
df = pd.DataFrame({
    "Name"   : names,
    "Math"   : math,
    "Science": science,
    "English": english
})

df["Total"]   = df["Math"] + df["Science"] + df["English"]
df["Average"] = df["Total"] / 3
df["Grade"]   = df["Average"].apply(
    lambda x: "A+" if x >= 90 else "A" if x >= 80 else
              "B"  if x >= 70 else "C" if x >= 60 else "D"
)

df_sorted = df.sort_values("Average", ascending=False).reset_index(drop=True)
print(df_sorted.to_string(index=False))

print(f"\nClass Average  : {df['Average'].mean():.2f}")
print(f"Topper         : {df.loc[df['Average'].idxmax(), 'Name']} ({df['Average'].max():.1f})")
print(f"Lowest         : {df.loc[df['Average'].idxmin(), 'Name']} ({df['Average'].min():.1f})")

grade_counts = df["Grade"].value_counts().sort_index()
print(f"\nGrade Distribution:\n{grade_counts}")

# ── Step 3: Visualize with Matplotlib ────────────
print("\n=== Step 3: Visualization with Matplotlib ===")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle("Student Data Analysis — NumPy + Pandas + Matplotlib", fontsize=14, fontweight='bold')

# Plot 1: Bar chart — average marks
ax1 = axes[0, 0]
colors = ['green' if x >= 75 else 'orange' if x >= 60 else 'red' for x in df_sorted["Average"]]
ax1.bar(df_sorted["Name"], df_sorted["Average"], color=colors, edgecolor='black')
ax1.axhline(y=df["Average"].mean(), color='blue', linestyle='--', label=f'Class Avg: {df["Average"].mean():.1f}')
ax1.set_title("Average Marks per Student")
ax1.set_ylabel("Average Marks")
ax1.tick_params(axis='x', rotation=45)
ax1.legend()
ax1.grid(axis='y', alpha=0.5)

# Plot 2: Line chart — subject comparison
ax2 = axes[0, 1]
x = np.arange(len(names))
ax2.plot(names, math,    marker='o', label='Math',    color='blue')
ax2.plot(names, science, marker='s', label='Science', color='green')
ax2.plot(names, english, marker='^', label='English', color='red')
ax2.set_title("Subject-wise Marks")
ax2.set_ylabel("Marks")
ax2.tick_params(axis='x', rotation=45)
ax2.legend()
ax2.grid(alpha=0.5)

# Plot 3: Pie chart — grade distribution
ax3 = axes[1, 0]
if not grade_counts.empty:
    ax3.pie(grade_counts.values, labels=grade_counts.index, autopct='%1.1f%%',
            colors=['gold', 'lightgreen', 'skyblue', 'salmon', 'plum'])
ax3.set_title("Grade Distribution")

# Plot 4: Histogram — total marks distribution
ax4 = axes[1, 1]
ax4.hist(df["Total"], bins=5, color='purple', edgecolor='black', alpha=0.8)
ax4.set_title("Total Marks Distribution")
ax4.set_xlabel("Total Marks")
ax4.set_ylabel("Number of Students")
ax4.grid(axis='y', alpha=0.5)

plt.tight_layout()
plt.savefig("data_analysis.png", dpi=100, bbox_inches='tight')
print("Analysis chart saved as 'data_analysis.png'")
plt.show()
print("\nDone! All 3 libraries used successfully.")
