# Q3. Write a program to demonstrate variable assignment and swapping values.

# ── Variable Assignment ───────────────────────────
x = 10
y = 20
print("=== Variable Assignment ===")
print(f"x = {x}")
print(f"y = {y}")

# ── Method 1: Swap using temp variable ────────────
print("\n=== Swap using Temporary Variable ===")
temp = x
x = y
y = temp
print(f"After swap: x = {x}, y = {y}")

# ── Method 2: Swap without temp (Pythonic way) ────
a = 100
b = 200
print("\n=== Swap using Python Tuple Unpacking ===")
print(f"Before swap: a = {a}, b = {b}")
a, b = b, a
print(f"After swap : a = {a}, b = {b}")

# ── Method 3: Swap using arithmetic ───────────────
p = 5
q = 7
print("\n=== Swap using Arithmetic (XOR) ===")
print(f"Before swap: p = {p}, q = {q}")
p = p ^ q
q = p ^ q
p = p ^ q
print(f"After swap : p = {p}, q = {q}")
