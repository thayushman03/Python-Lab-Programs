# Q25. Write a program demonstrating multiple exceptions handling.

print("=== Multiple Exception Handling ===\n")

def divide(a, b):
    return a / b

def get_element(lst, idx):
    return lst[idx]

def open_file(filename):
    with open(filename, "r") as f:
        return f.read()

def convert_to_int(value):
    return int(value)

# ── Test 1: Multiple except blocks ────────────────
print("--- Test 1: Division ---")
try:
    x = float(input("Enter a number: "))
    y = float(input("Enter another : "))
    print(f"Result: {divide(x, y):.2f}")
except ZeroDivisionError:
    print("Cannot divide by zero!")
except ValueError:
    print("Invalid input! Enter numbers only.")
except TypeError:
    print("Type error occurred!")

# ── Test 2: Multiple exceptions in one line ────────
print("\n--- Test 2: List access ---")
numbers = [1, 2, 3, 4, 5]
try:
    idx = int(input(f"Enter index (0-{len(numbers)-1}): "))
    print(f"Element: {get_element(numbers, idx)}")
except (IndexError, ValueError) as e:
    print(f"Error: {e}")

# ── Test 3: Chained exceptions ────────────────────
print("\n--- Test 3: File + conversion ---")
try:
    result = open_file("data.txt")
    number = convert_to_int(result.strip())
    print(f"Number from file: {number}")
except FileNotFoundError:
    print("File not found!")
except ValueError:
    print("File content is not a valid number!")
except Exception as e:
    print(f"Unexpected error: {e}")

# ── Test 4: Catching all exceptions ───────────────
print("\n--- Test 4: Generic exception ---")
try:
    val = input("Enter something: ")
    result = 100 / int(val)
    print(f"100 / {val} = {result:.2f}")
except ZeroDivisionError:
    print("Division by zero!")
except ValueError:
    print("Not a number!")
except Exception as e:
    print(f"Some error occurred: {type(e).__name__}: {e}")
finally:
    print("Program executed (finally block).")
