# Q14. Write a program to perform dictionary operations (add, update, delete).

student = {
    "name"    : "Ayushman Singh",
    "roll"    : "Y24170523",
    "course"  : "BCA",
    "semester": "IV",
    "marks"   : 85
}

print("=== Original Dictionary ===")
for k, v in student.items():
    print(f"  {k}: {v}")

# ── Add ───────────────────────────────────────────
print("\n=== Add new key 'email' ===")
student["email"] = "ayushman@example.com"
print(f"  Added email: {student['email']}")

# ── Update ────────────────────────────────────────
print("\n=== Update 'marks' to 90 ===")
student["marks"] = 90
print(f"  Updated marks: {student['marks']}")

student.update({"semester": "IV", "course": "BCA IV"})
print(f"  Updated using update(): {student['course']}")

# ── Delete ────────────────────────────────────────
print("\n=== Delete 'email' key ===")
del student["email"]
print(f"  Deleted email key. Keys now: {list(student.keys())}")

# pop
popped = student.pop("marks")
print(f"  Popped 'marks': {popped}")

# ── Other Operations ──────────────────────────────
print("\n=== Other Dictionary Operations ===")
print(f"  All keys   : {list(student.keys())}")
print(f"  All values : {list(student.values())}")
print(f"  Length     : {len(student)}")
print(f"  'name' in dict? : {'name' in student}")
print(f"  Get with default: {student.get('age', 'Not Found')}")

# ── Final Dictionary ──────────────────────────────
print("\n=== Final Dictionary ===")
for k, v in student.items():
    print(f"  {k}: {v}")
