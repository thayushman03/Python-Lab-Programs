# Q11. Write a program to count frequency of characters in a string.

s = input("Enter a string: ").lower()

print(f"\n=== Character Frequency in '{s}' ===")

freq = {}
for char in s:
    if char == ' ':
        continue  # skip spaces
    freq[char] = freq.get(char, 0) + 1

# Sort by frequency (highest first)
sorted_freq = sorted(freq.items(), key=lambda x: x[1], reverse=True)

print(f"{'Character':<12} {'Frequency':<10} {'Bar'}")
print("-" * 40)
for char, count in sorted_freq:
    bar = '█' * count
    print(f"'{char}'          {count:<10} {bar}")

print(f"\nTotal unique characters: {len(freq)}")
print(f"Most frequent character: '{sorted_freq[0][0]}' ({sorted_freq[0][1]} times)")
